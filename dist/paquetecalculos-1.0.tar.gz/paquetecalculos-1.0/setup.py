from setuptools import setup

setup(
    name="paquetecalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Javier",
    author_email="roucox2@gmail.com",
    url="www.google.com",
    packages=["calculos", "calculos.basicos", "calculos.redondeo_potencia"] #paquetes a incluir

)